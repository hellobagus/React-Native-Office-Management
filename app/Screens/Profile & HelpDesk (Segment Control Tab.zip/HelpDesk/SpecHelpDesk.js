import React, { Component } from "react";
import { 
    View,
    StyleSheet,
    TouchableOpacity,
    Image,
    SegmentedControlIOS
} from "react-native";
import {Container, Content, Text, H2, Icon, List, ListItem,Button} from 'native-base'
import nbStyles from './Style'
import Style from '@Theme/Style'
import SegmentedControlTab from 'react-native-segmented-control-tab'

class SpecHelpDesk extends Component {

    static options(passProps){
        return {
            topBar : {
                noBorder:true
            }
        }
    }
    
    constructor(props){
        super(props);

        this.state = {
            selectedIndex : 0
        }
    }

    handleIndexChange = (index) => {
        this.setState({
          ...this.state,
          selectedIndex: index,
        });

        console.log('Selected index', this.state.selectedIndex)
      }

    render() {
        return (
            <Container>
                <Content>
                    <View style={nbStyles.wrap}>
                        <View style={nbStyles.subWrap}>
                            <Text style={nbStyles.title}>Help Desk</Text>
                        </View>
                        <View style={nbStyles.subWrap}>
                            <Text style={nbStyles.subTitle}>Spesification Help Desk</Text>
                        </View>
                        <View style={nbStyles.subWrap}>
                            
                            <SegmentedControlTab
                            values={['Complain', 'Request', 'Application']}
                            selectedIndex={this.state.selectedIndex}
                            onTabPress={this.handleIndexChange}
                            activeTabStyle={nbStyles.activeTabStyle}
                            activeTabTextStyle={nbStyles.activeTabTextStyle}
                            tabStyle={nbStyles.tabStyle}
                            tabTextStyle={nbStyles.tabTextStyle}
                            />
                            {/* SELECT TAB OPTION IN HERE */}

                                {/* SELECTED TAB COMPLAIN */}
                                {this.state.selectedIndex === 0 &&
                                <View style={nbStyles.subWrap}>
                                    <View style={nbStyles.radioLayoutBottomBordered}>
                                        <TouchableOpacity style={nbStyles.btnBox2}>
                                            <Text style={nbStyles.textButton}>Tower 1</Text>
                                        </TouchableOpacity>
        
                                        <TouchableOpacity style={nbStyles.btnBox2}>
                                            <Text style={nbStyles.textButton}>Tower 2</Text>
                                        </TouchableOpacity>
        
                                        <TouchableOpacity style={nbStyles.btnBox2}>
                                            <Text style={nbStyles.textButton}>Tower 3</Text>
                                        </TouchableOpacity>
                                    </View>
                                    <View style={nbStyles.radioLayout}>
                                        <TouchableOpacity style={nbStyles.btnBox2}>
                                            <Text style={nbStyles.textButton}>Unit 1</Text>
                                        </TouchableOpacity>
        
                                        <TouchableOpacity style={nbStyles.btnBox2}>
                                            <Text style={nbStyles.textButton}>Unit 2</Text>
                                        </TouchableOpacity>
        
                                        <TouchableOpacity style={nbStyles.btnBox2}>
                                            <Text style={nbStyles.textButton}>Unit 3</Text>
                                        </TouchableOpacity>
                                    </View>
                                </View>
                                }
                                {/* END TAB COMPLAIN */}

                                {/* SELECTED TAB REQUEST */}
                                {this.state.selectedIndex === 1 &&
                                <Text style={nbStyles.tabContent}> Tab two</Text>}
                                {/* END TAB REQUEST */}

                                {/* SELECTED TAB APPLICATION */}
                                {this.state.selectedIndex === 2 &&
                                <Text style={nbStyles.tabContent}> Tab three</Text>}
                                {/* END TAB APPLICATION */}

                            {/* SELECTED TAB END */}
                        </View>
                        
                        <View style={nbStyles.subWrap}>
                            <Button block style={Style.buttonSubmit}>
                                <Text>Next</Text>
                            </Button>
                        </View>
                    </View>
                </Content>
            </Container>
        );
    }
}
export default SpecHelpDesk;
