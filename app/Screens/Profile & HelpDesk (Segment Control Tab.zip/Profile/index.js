import React, { Component } from "react";
import { 
    View,
    Text,
    StyleSheet, ImageBackground,Image,TouchableOpacity,AsyncStorage
} from "react-native";
import { Container, Content, Icon, Button } from "native-base";
import nbStyles from './Style'
import {goToAuth} from '../navigation'
import {USER_KEY} from '../config'

class Profile extends Component {

    logout = async () => {
        try {
          await AsyncStorage.removeItem(USER_KEY)
          goToAuth()
        } catch (err) {
          console.log('error signing out...: ', err)
        }
    }
    render() {
        return (
            <Container style={nbStyles.content}>
                <ImageBackground source={require('@Asset/images/background-login.png')} style={{flex:1, resizeMode: 'cover'}}>
                    <Content>
                        <View style={nbStyles.Wrap}>
                            <Text style={nbStyles.headerText}>Profile</Text>
                            <TouchableOpacity transparent>
                                <Icon name="edit" type="FontAwesome" style={nbStyles.icon}></Icon>
                            </TouchableOpacity>
                        </View>
                        <View style={nbStyles.subWrap}>
                            <Image source={require('@Asset/images/logo.png')} style={nbStyles.image}/>
                        </View>
                        <View style={nbStyles.subWrap}>
                            <Text style={nbStyles.labelText}>Username</Text>
                            <Text style={nbStyles.contentText}>Bagus</Text>
                        </View>
                        <View style={nbStyles.subWrap}>
                            <Text style={nbStyles.labelText}>Email</Text>
                            <Text style={nbStyles.contentText}>bagus@gmail.com</Text>
                        </View>
                        <View style={nbStyles.subWrap}>
                            <Text style={nbStyles.labelText}>Telepon</Text>
                            <Text style={nbStyles.contentText}>081219880482</Text>
                        </View>
                        <View style={nbStyles.subWrap}>
                            <TouchableOpacity onPress={()=> this.logout()}>
                                <Text style={nbStyles.buttonText}>Logout</Text>
                            </TouchableOpacity>
                        </View>
                    </Content>
                </ImageBackground>
            </Container>
        );
    }
}
export default Profile;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center'
    }
});