export default {
    content :{
        width: '100%',
        justifyContent: 'center',
    },
    Wrap : {
        flexDirection : 'row',
        justifyContent : 'space-between',
        marginHorizontal : 32,
        marginVertical : 32
    },
    subWrap :{
        marginHorizontal : 32,
        marginVertical : 8
    },
    icon : {
        color : '#fff',
        fontSize : 25
    },
    headerText : {
        color : '#fff',
        fontSize : 20,
        fontFamily : 'Montserrat-Regular'
    },
    labelText :{
        color : '#fff',
        fontSize : 15,
        fontFamily : 'Montserrat-Regular'
    },
    contentText :{
        color : '#fff',
        fontSize : 18,
        fontFamily : 'Montserrat-Regular'
    },
    buttonText : {
        color : '#fff',
        fontSize : 16.5,
        fontFamily : 'Montserrat-Regular'
    },
    image : {
        // width : 100,
        // height : 100
    },

}