import React from 'react'
import { StyleSheet, Button, View, Image,AsyncStorage} from 'react-native'
import email from 'react-native-email'
import { Container, Content, Card, Text } from 'native-base'
import nbStyles from './Style'
import CardNotification from '@Component/Notification/CardNotification'
export default class Inbox extends React.Component {

    constructor(props){
        super(props)
        this.state = {
            email : '',
            dataNotification : [],
        }
    }

    async componentWillMount(){
        const datas =  {
            email : await AsyncStorage.getItem("@User"),
            
        }

        this.getNotification(datas)
    }

    getNotification = (data) => {
        const formData = {
            email : data.email
        }
        console.log('datasssss', email)

        fetch('http://35.198.219.220:2121/alfaAPI/c_notification/getNotification/IFCAMOBILE',{
            method : "POST",
            body :JSON.stringify(formData)
        })
        .then((response) => response.json())
        .then((res)=>{
            this.setState({dataOvertime:[]})
            if(res.Error === false){
                // console.log('ResData', JSON.stringify(res.Data))
                let resData = res.Data;
                this.setState({dataNotification : resData})
                
            }
            console.log('datar', res)

        }).catch((error) => {
            console.log(error);
        });
    }
    render() {
        return (
            <Container>
                <Content>
                    <View style={nbStyles.wrap}>
                        <View style={nbStyles.subWrap}>
                            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                                <Text style={nbStyles.title}>Status</Text>
                            </View>
                        </View>
                        <View style={styles.container}>
                            <Button title="Send Mail" onPress={this.handleEmail} style={styles.Button} />
                        </View>
                        
                    </View>
                    <View style={{marginTop: 30}}>
                        {this.state.dataNotification.map((data,key)=>
                            <CardNotification key={key} data={data}></CardNotification>
                        )}
                    </View>
                </Content>
            </Container>

        )
    }

    handleEmail = () => {
        const to = ['bagustrinanda@yahoo.com', 'nandatribagus@gmail.com'] // string or array of email addresses
        email(to, {
            // Optional additional arguments
            cc: ['bazzy@moo.com', 'doooo@daaa.com'], // string or array of email addresses
            bcc: 'mee@mee.com', // string or array of email addresses
            subject: 'Show how to use',
            body: 'Some body right here'
        }).catch(console.error)
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#f5f5f5',
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 5
    },
    Button: {
        backgroundColor: '#f5f5f5'

    }
})