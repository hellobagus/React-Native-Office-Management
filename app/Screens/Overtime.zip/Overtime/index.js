import React, { Component } from "react";
import { 
    View,
    StyleSheet,
    AsyncStorage
} from "react-native";
import {Container, 
    Content,
    Text,
    DatePicker,Button, Card
} from 'native-base'
import nbStyles from './Style'
import {Navigation} from 'react-native-navigation';

class Overtime extends Component {
    static options(passProps){
        return {
            topBar : {
                noBorder:true
            }
        }
    }
    
    constructor(props) {
        super(props);
        this.state = { 
            chosenDate: new Date(),

            email : '',

            dataTower : [],
            dataOvertime : []
        };
        this.setDate = this.setDate.bind(this);
    }

    setDate(newDate) {
        this.setState({ chosenDate: newDate },()=>{
            this.getOvertime()            
        });
    }

    async componentWillMount(){
        const datas =  {
            email : await AsyncStorage.getItem("@User"),
            
        }

        this.loadData(datas)
    }

    loadData = (datas) => {
        this.setState(datas,()=>{
            this.getTower()
        })
    }

    getTower = () => {
        let email = this.state.email;

        fetch('http://35.198.219.220:2121/alfaAPI/c_product_info/getData/IFCAMOBILE/'+email,{
            method : "GET",
            headers : new Headers({
                'Token': 'JXmiUMx0+cg40ee5SU8Jc6xDKP7/XIfsTPjp1PdlLWptSTq/aaEJvTCTx4S98QeJdetlqFj2VbI+D6PqELUuk+5ZxxvS8ujvUdz0CqAS::268e8fa2a99a1dda0bae16f556d6403e'
            })
        })
        .then((response) => response.json())
        .then((res)=>{
            if(res.Error === false){
                this.setState({dataTower:[]})
                    let resData = res.Data
                    for(var i = 0 ; i < resData.length; i++){
                        
                        this.setState(prevState => ({
                            dataTower: [...prevState.dataTower, resData[i]]
                        }))
                    }
                    this.getOvertime()
                    this.getLot()
                
            }
            console.log('datasss', res)
        }).catch((error) => {
            console.log(error);
        });
    }
    getOvertime = () => {
        const dT = this.state.dataTower[0]
        console.log('tag', dT)

        const formData = {
            entity_cd : dT.entity_cd,
            project_no : dT.project_no,
            ov_date : this.state.chosenDate
        }
        console.log('datasssss', formData)

        fetch('http://35.198.219.220:2121/alfaAPI/c_overtime/getData/IFCAPB',{
            method : "POST",
            body :JSON.stringify(formData)
        })
        .then((response) => response.json())
        .then((res)=>{
            this.setState({dataOvertime:[]})
            if(res.Error === false){
                // console.log('ResData', JSON.stringify(res.Data))
                let resData = res.Data;
                for(var i = 0 ; i < resData.length; i++){

                    this.setState(prevState => ({
                        dataOvertime: [...prevState.dataOvertime, resData[i]]
                    }))
                }

                
            }
            console.log('datar', res)

        }).catch((error) => {
            console.log(error);
        });
    }

    getLot = () => {
        const dT = this.state.dataTower[0]

        const formData = {
            entity_cd : dT.entity_cd,
            project_no : dT.project_no
        }

        fetch('http://35.198.219.220:2121/alfaAPI/c_overtime/zoom_lot_no/IFCAPB',{
            method : "POST",
            body :JSON.stringify(formData)
        })
        .then((response) => response.json())
        .then((res)=>{
            if(res.Error === false){
                this.setState({dataLot:[]})
                console.log('ResData', JSON.stringify(res.Data))
                let resData = res.Data;
                for(var i = 0 ; i < resData.length; i++){

                    this.setState(prevState => ({
                        dataLot: [...prevState.dataLot, resData[i]]
                    }))
                    // console.log('ssss', resData[i])
                }
                // this.setState({dataLot : [resData]})

                
            }
            console.log('datar', res)

        }).catch((error) => {
            console.log(error);
        });
    }


    handleIndexChange = (index) => {
        this.setState({
            ...this.state,
            selectedIndex: index,
        });

        console.log('Selected index', this.state.selectedIndex)
    }

    goToScreen = (screenName) => {
        Navigation.push(this.props.componentId,{
            component:{
                name : screenName,
                passProps :{
                    chosenDate : this.state.chosenDate,
                    dataLot : this.state.dataLot,
                    dataTower : this.state.dataTower[0]
                }
            }
        })
    }

    render() {
        return (
           <Container>
                <Content>
                    <View style={nbStyles.wrap}>
                        <View style={nbStyles.subWrap}>
                            <View style={{flexDirection:'row', justifyContent:'space-between'}}>
                                <Text style={nbStyles.title}>Overtime</Text>
                            </View>
                            <Text style={{fontSize:12, marginTop: 16}}> Select Date Overtime</Text>
                        </View>
                        <Text style={{fontSize:12, marginLeft: 12, marginTop: 16}}>
                            Date: {this.state.chosenDate.toString().substr(4, 12)}
                        </Text>
                        <View style={{flexDirection:'row', justifyContent:'space-between'}}>
                            <View style={{marginTop:16}}>
                                <DatePicker
                                    defaultDate={new Date(2018, 4, 4)}
                                    minimumDate={new Date(2018, 1, 1)}
                                    maximumDate={new Date(2018, 12, 31)}
                                    locale={"id"}
                                    timeZoneOffsetInMinutes={undefined}
                                    modalTransparent={false}
                                    animationType={"fade"}
                                    androidMode={"default"}
                                    placeHolderText="Select date and time"
                                    textStyle={{ color: "green" }}
                                    placeHolderTextStyle={{ color: "#d3d3d3" }}
                                    onDateChange={this.setDate}
                                    disabled={false}
                                />
                            </View>
                            <Button small style={{color: "#37BEB7", padding: 20, marginRight: 16, marginTop: 16}}
                                onPress={()=>this.goToScreen('screen.AddOvertime')}  >
                                <Text> Add New</Text>
                            </Button>
                        </View>
                            <View style={styles.listview}>
                            {this.state.dataOvertime.map((data,key)=>
                                <Card key={key} style={{
                                    height:null,
                                    backgroundColor: 'white',
                                    shadowOffset : { width:1, height: 1},
                                    shadowColor:"#37BEB7",
                                    shadowOpacity:0.5,
                                    elevation:5,
                                    paddingHorizontal:10,
                                    paddingVertical:10
                                    }}>
                                    <View>
                                        <View style={{flexDirection:'row', justifyContent:'space-between'}}>
                                            <Text style={{
                                                fontSize: 18,
                                                fontWeight:'500',
                                                textAlign:'left'
                                            }}>
                                                {data.lot_no}
                                            </Text>
                                            <Text style={{
                                                fontSize: 12,
                                                fontWeight:'500',
                                                textAlign:'right',
                                                color:'#9B9B9B'
                                            }}>
                                                Start : {data.start_overtime.toString().substr(11, 5)}
                                            </Text>
                                        </View>
                                        <View style={{flexDirection:'row', justifyContent:'space-between'}}>
                                            <Text style={{
                                                fontSize: 16,
                                                fontWeight:'500',
                                                textAlign:'left',
                                                color:'#F99B23'
                                            }}>
                                                {data.name_debtor}
                                            </Text>
                                            <View>
                                                <Text style={{
                                                    fontSize: 12,
                                                    fontWeight:'500',
                                                    textAlign:'right',
                                                    color:'#9B9B9B'
                                                }}>
                                                   End : {data.end_overtime.toString().substr(11, 5)}
                                                </Text>
                                            </View>
                                        </View>
                                        <View style={{flexDirection:'row', justifyContent:'space-between'}}>
                                            <Text style={{
                                                fontSize: 12,
                                                fontWeight:'300',
                                                textAlign:'left',
                                                color:'#9B9B9B'
                                            }}>
                                                Overtime Date : {data.start_overtime.toString().substr(0, 10)}
                                            </Text>
                                        </View>                                       
                                        
                                    </View>
                                </Card>    
                                
                            )}
                            

                        </View>
                    </View>
               </Content>
           </Container>
        );
    }
}
export default Overtime;

const styles = StyleSheet.create({
    listview: {
        marginTop: 54
    },
    listitemm: {
        height: 100
    }
});
