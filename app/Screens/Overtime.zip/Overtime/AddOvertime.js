import React, { Component } from "react";
import {
    View,
    StyleSheet,
    TextInput,
    TouchableOpacity,
    AsyncStorage
} from "react-native";
import {
    Container,
    Content,
    Text,
    DatePicker, 
    Title, Button, Icon, Right, Body, Left, Picker, Form, Header
} from 'native-base'
import DateTimePicker from 'react-native-modal-datetime-picker';
import moment from 'moment'
import nbStyles from './Style'
import Style from '@Theme/Style'
import ModalSelector from 'react-native-modal-selector'
import SegmentedControlTab from 'react-native-segmented-control-tab'

class AddOvertime extends Component {
    static options(passProps) {
        return {
            topBar: {
                noBorder: true
            }
        }
    }

    constructor(props) {
        super(props);
        this.state = { 
            selected: "key1",
            chosenDate : moment(props.chosenDate).format('DD-MM-YYYY'),
            dataLot : props.dataLot,

            textLot : '',
            levelNo : '',
            debtorAcct : '',
            descsLevel : '',

            isVisible: false,
            startVisible:false,
            endVisible : false,
            
            startTime : '',
            endTime : ''
        };

        console.log('props', props)
        
        this.setDate = this.setDate.bind(this);
    }

    componentDidMount(){
        this.loadData()
    }

    loadData = () => {
        // const data = 
        
        // this.savaOvertime(data)
    }

    savaOvertime = async()=>{
        const dataTower = this.props.dataTower
        const {textLot,debtorAcct,levelNo,descsLevel,startTime,endTime,chosenDate} = this.state

        const formData = {
            business_id : await AsyncStorage.getItem('@UserId'),
            entity : dataTower.entity_cd,
            project_no : dataTower.project_no,
            ot_Id : 0,
            lotno : textLot + '-%-' + debtorAcct + '-%-' + levelNo + '-%-' + descsLevel,
            descs : 'Overtime ',
            ov_date : chosenDate,
            startHour : startTime+':00',
            endHour : endTime+':00'
        }

        console.log('formData', formData)

        fetch('http://35.198.219.220:2121/alfaAPI/c_overtime/save/IFCAPB',{
            method : "POST",
            body :JSON.stringify(formData)
        })
        .then((response) => response.json())
        .then((res)=>{
            if(res.Error === false){
                // this.setState({dataLot:[]})
                // console.log('ResData', JSON.stringify(res.Data))
                // let resData = res.Data;
                // for(var i = 0 ; i < resData.length; i++){

                //     this.setState(prevState => ({
                //         dataLot: [...prevState.dataLot, resData[i]]
                //     }))
                //     // console.log('ssss', resData[i])
                // }
                // this.setState({dataLot : [resData]})

                
            }
            console.log('datar', res)

        }).catch((error) => {
            console.log(error);
        });
    }

    onValueChange(value: string) {
        this.setState({
            selected: value
        });
    }

    setDate(newDate) {
        this.setState({ chosenDate: newDate });
    }

    handleLotChange =(lot) => {
        this.setState({
            textLot : lot.lot_no,
            levelNo : lot.level_no,
            debtorAcct : lot.debtor_acct,
            descsLevel : lot.descs_level
        })
    }

    handleIndexChange = (index) => {
        this.setState({
            ...this.state,
            selectedIndex: index,
        });

        console.log('Selected index', this.state.selectedIndex)
    }

    showPicker = (data) => data == 'startTime' ? this.setState({ startVisible: true }) : this.setState({ endVisible: true });
 
    hidePicker = (data) => data == 'startTime' ? this.setState({ startVisible: false }) : this.setState({ endVisible: false });
    
    handlePicker = (type,time) => {
        type == 'startTime' 
        ?
        this.setState({
            startVisible : false,
            startTime : moment(time).format('HH:mm')
        })
        :
        this.setState({
            endVisible : false,
            endTime : moment(time).format('HH:mm')
        })

    };

    render() {
        
        return (
            <Container>
                <Content>
                    <View style={nbStyles.wrap}>
                        <View style={nbStyles.subWrap}>
                            <View style={nbStyles.subWrap}>
                                <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>

                                    <Text style={nbStyles.title}>Overtime</Text>
                                </View>
                                <Text style={{ fontSize: 12, marginTop: 16 }}> Select Date Overtime</Text>
                            </View>
                        </View>
                        <View style={nbStyles.subWrap}>
                        
                            <View style={nbStyles.subWrap}>
                                <ModalSelector
                                        data={this.state.dataLot}
                                        optionTextStyle={{color:"#333"}}
                                        selectedItemTextStyle={{color:'#3C85F1'}}
                                        accessible={true}
                                        keyExtractor= {item => item.lot_no}
                                        labelExtractor= {item => item.lot_no}
                                        cancelButtonAccessibilityLabel={'Cancel Button'}
                                        onChange={(option)=>{ this.handleLotChange(option)}}>
                                        <TextInput style={styles.input} onFocus={() => this.selector.open()} 
                                            placeholder="Lot No"
                                            editable={false}
                                            placeholderTextColor='#a9a9a9'
                                            value={this.state.textLot}
                                        />
                                </ModalSelector>
                            </View>

                            <View style={nbStyles.subWrap}>
                                <Text style={{ fontSize: 12, marginTop: 16 }}>
                                    Date: {this.state.chosenDate}
                                </Text>
                            </View>
                            
                            <View style={nbStyles.subWrap}>
                                <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                                    <View style={{ marginTop: 16 }}>
                                        <TouchableOpacity onPress={(key)=>this.showPicker('startTime')}>
                                            <TextInput style={styles.inputTime} 
                                                placeholder="Start Time"
                                                editable={false}
                                                placeholderTextColor='#a9a9a9'
                                                value={this.state.startTime}
                                            />
                                        </TouchableOpacity>
                                        <DateTimePicker
                                            mode = {'time'}
                                            is24Hour={true}
                                            isVisible={this.state.startVisible}
                                            onConfirm={(val)=>{this.handlePicker('startTime',val)}}
                                            onCancel={()=>this.hidePicker('startTime')}
                                            datePickerModeAndroid={'spinner'}
                                        />
                                    </View>
                                    <View style={{ marginTop: 16 }}>
                                        <TouchableOpacity onPress={this.showPicker}>
                                            <TextInput style={styles.inputTime} 
                                                placeholder="End Time"
                                                editable={false}
                                                placeholderTextColor='#a9a9a9'
                                                value={this.state.endTime}
                                            />
                                        </TouchableOpacity>
                                        <DateTimePicker
                                            mode = {'time'}
                                            is24Hour={true}
                                            isVisible={this.state.endVisible}
                                            onConfirm={(val)=>{this.handlePicker('endTime',val)}}
                                            onCancel={()=>this.hidePicker('endTime')}
                                            datePickerModeAndroid={'spinner'}
                                        />
                                    </View>
                                </View>
                            </View>
                            <View style={nbStyles.subWrap}>
                                <Button block style={Style.buttonSubmit} onPress={()=>this.savaOvertime()}>
                                    <Text>SEND</Text>
                                </Button>
                            </View>
                        </View>
                    </View>
                </Content>
            </Container>
        );
    }
}
export default AddOvertime;


const styles = StyleSheet.create({

    input :{
        height: 40,
        backgroundColor: '#f5f5f5',
        color:"black",
        paddingHorizontal: 10,
        marginBottom: 16,
        width: null,
        borderRadius: 10,
        justifyContent: 'center',
        alignItems: 'center'
    },

    inputTime :{
        height: 40,
        backgroundColor: '#f5f5f5',
        color:"black",
        paddingHorizontal: 10,
        marginBottom: 16,
        width: 90,
        borderRadius: 10,
        justifyContent: 'center',
        alignItems: 'center',
        textAlign : 'center'
    }
})